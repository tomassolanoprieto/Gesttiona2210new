import React from 'react';
import { HeroSection } from '../components/ui/HeroSection';
import { Contact } from '../components/Contact';

export function ContactPage() {
  return (
    <div>
      <HeroSection
        title="Contacta con Nosotros"
        subtitle="Estamos aquí para ayudarte. Ponte en contacto con nuestro equipo de expertos"
        backgroundImage="https://images.unsplash.com/photo-1423666639041-f56000c27a9a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
      />
      <Contact />
    </div>
  );
}