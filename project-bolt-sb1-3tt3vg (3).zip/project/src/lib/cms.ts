import matter from 'gray-matter';
import { marked } from 'marked';

export async function getBlogPosts() {
  const context = import.meta.glob('../content/blog/*.md');
  const posts = await Promise.all(
    Object.keys(context).map(async (key) => {
      const post = await context[key]();
      const { data, content } = matter(post.default);
      return {
        ...data,
        content: marked(content),
        slug: key.replace('../content/blog/', '').replace('.md', '')
      };
    })
  );
  return posts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export async function getProperties() {
  const context = import.meta.glob('../content/properties/*.md');
  const properties = await Promise.all(
    Object.keys(context).map(async (key) => {
      const property = await context[key]();
      const { data } = matter(property.default);
      return {
        ...data,
        slug: key.replace('../content/properties/', '').replace('.md', '')
      };
    })
  );
  return properties;
}